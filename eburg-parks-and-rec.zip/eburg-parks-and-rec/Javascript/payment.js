const paymentForm = document.getElementById("payment");

paymentForm.addEventListener("submit", (e) => {
    console.log("this works");
})